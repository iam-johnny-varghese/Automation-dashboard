export const QUARTERS = ["Q1 2025", "Q2 2025", "Q3 2025", "Q4 2025"];

/**
 * AUTOMATION_AREAS — 16 domains (8 Platform + 8 DBA-specific)
 *
 * SCORING FORMULA:
 *   coverage% = Σ(completed task weights) / Σ(all task weights) × 100
 *
 * UPDATE EACH QUARTER:
 *   1. Mark tasks complete/incomplete in your tracker
 *   2. Sum completed weights per domain
 *   3. Divide by total weights × 100
 *   4. Append new quarter value to quarterly[]
 */

// ─────────────────────────────────────────────
//  GROUP A — PLATFORM OPERATIONS (original 8)
// ─────────────────────────────────────────────
export const PLATFORM_DOMAINS = [
  {
    id: "perf_obs",
    label: "Performance Monitoring & Observability",
    icon: "📊",
    color: "#00C2FF",
    description:
      "DBQL anomaly detection, workload monitoring, query performance alerting, SLA breach detection, real-time dashboards",
    tasks: [
      { name: "DBQL ingestion & anomaly detection", weight: 15 },
      { name: "Workload & concurrency monitoring", weight: 12 },
      { name: "SLA breach alerting (ServiceNow)", weight: 12 },
      { name: "Real-time performance dashboards", weight: 10 },
      { name: "Active session & blocking detection", weight: 10 },
      { name: "Node / vproc health checks", weight: 10 },
      { name: "Query classification & tagging", weight: 8 },
      { name: "Skew & spool monitoring", weight: 8 },
      { name: "Historical trend reporting", weight: 8 },
      { name: "Automated explain plan analysis", weight: 7 },
    ],
    quarterly: [35, 52, 68, 80],
  },
  {
    id: "security_gov",
    label: "Security & Governance Automation",
    icon: "🔐",
    color: "#A78BFA",
    description:
      "PCI zone enforcement, Secure Zone provisioning, access log behavioral analytics, role provisioning, audit reporting",
    tasks: [
      { name: "Secure Zone provisioning & validation", weight: 15 },
      { name: "PCI zone isolation enforcement", weight: 12 },
      { name: "Access log behavioral anomaly detection", weight: 12 },
      { name: "Role & profile automated provisioning", weight: 10 },
      { name: "DBC.LogonOff / AccessLog alerting", weight: 10 },
      { name: "DDL change audit trail", weight: 9 },
      { name: "Quarterly access certification reports", weight: 8 },
      { name: "Creator rights governance checks", weight: 8 },
      { name: "Password & logon policy auditing", weight: 8 },
      { name: "UDF protected mode enforcement", weight: 8 },
    ],
    quarterly: [20, 38, 55, 70],
  },
  {
    id: "infra_deploy",
    label: "Infrastructure & Deployment Automation",
    icon: "⚙️",
    color: "#34D399",
    description:
      "Environment provisioning, schema deployment pipelines, QueryGrid config, release management, config-as-code",
    tasks: [
      { name: "Schema & object deployment pipelines", weight: 15 },
      { name: "QueryGrid connector provisioning", weight: 12 },
      { name: "Environment baseline config-as-code", weight: 12 },
      { name: "Release management & rollback scripts", weight: 10 },
      { name: "Automated regression test suites", weight: 10 },
      { name: "Service account provisioning", weight: 10 },
      { name: "TD system parameter drift detection", weight: 8 },
      { name: "Space quota allocation automation", weight: 8 },
      { name: "Multi-environment promotion workflows", weight: 8 },
      { name: "DR failover readiness checks", weight: 7 },
    ],
    quarterly: [25, 40, 58, 72],
  },
  {
    id: "capacity_mgmt",
    label: "Capacity Management & Forecasting",
    icon: "📈",
    color: "#FBBF24",
    description:
      "Prophet/ML forecasting, perm space trending, AWT pool analysis, inorganic growth modeling, ServiceNow capacity alerts",
    tasks: [
      { name: "Perm space trending & forecasting", weight: 15 },
      { name: "ML ensemble capacity models (Prophet/XGB)", weight: 15 },
      { name: "AWT pool utilisation analysis", weight: 10 },
      { name: "Capacity threshold alerting", weight: 10 },
      { name: "Tenant-level space attribution", weight: 10 },
      { name: "Inorganic growth event modeling", weight: 8 },
      { name: "ServiceNow capacity incident creation", weight: 8 },
      { name: "CPU / IO saturation forecasting", weight: 8 },
      { name: "Growth recommendation engine", weight: 8 },
      { name: "Executive capacity reports", weight: 8 },
    ],
    quarterly: [40, 60, 75, 85],
  },
  {
    id: "data_lifecycle",
    label: "Data Lifecycle & Quality Automation",
    icon: "🔄",
    color: "#F87171",
    description:
      "Data retention enforcement, archival pipelines, lineage tracking, redundancy detection, data quality rule automation",
    tasks: [
      { name: "Data lineage graph generation", weight: 15 },
      { name: "Redundancy & duplication detection", weight: 12 },
      { name: "Retention policy enforcement", weight: 12 },
      { name: "Automated archival & purge pipelines", weight: 12 },
      { name: "Data quality rule automation", weight: 10 },
      { name: "Stats freshness monitoring", weight: 8 },
      { name: "Schema drift detection", weight: 8 },
      { name: "Stale object detection & cleanup", weight: 8 },
      { name: "Partition elimination validation", weight: 8 },
      { name: "Cross-platform lineage (TD↔BQ↔Hadoop)", weight: 7 },
    ],
    quarterly: [15, 30, 48, 62],
  },
  {
    id: "cost_finops",
    label: "Cost Visibility & FinOps Automation",
    icon: "💰",
    color: "#38BDF8",
    description:
      "Cost-per-query attribution, tenant chargeback, FinOps dashboards, Cloudability/Apptio integration, workload cost tagging",
    tasks: [
      { name: "Cost-per-query attribution engine", weight: 15 },
      { name: "Tenant chargeback reporting", weight: 15 },
      { name: "Cost anomaly alerting", weight: 10 },
      { name: "FinOps executive dashboards", weight: 10 },
      { name: "Workload cost tagging & classification", weight: 10 },
      { name: "Idle resource detection", weight: 8 },
      { name: "GCP BigQuery cost integration", weight: 8 },
      { name: "Cloudability / Apptio data feeds", weight: 8 },
      { name: "Cross-platform cost normalisation", weight: 8 },
      { name: "Automated cost optimisation recommendations", weight: 8 },
    ],
    quarterly: [30, 48, 62, 75],
  },
  {
    id: "incident_ops",
    label: "Incident Management & AIOps",
    icon: "🚨",
    color: "#FB923C",
    description:
      "ServiceNow incident auto-creation, MTTR tracking, runbook automation, alert correlation, on-call routing",
    tasks: [
      { name: "Automated incident creation (ServiceNow)", weight: 15 },
      { name: "MTTR / DORA metrics tracking", weight: 12 },
      { name: "Alert correlation & deduplication", weight: 12 },
      { name: "Runbook automation execution", weight: 12 },
      { name: "Root cause suggestion (AI-assisted)", weight: 10 },
      { name: "On-call routing & escalation", weight: 8 },
      { name: "Post-incident report generation", weight: 8 },
      { name: "Problem record linkage", weight: 8 },
      { name: "Change-to-incident correlation", weight: 8 },
      { name: "SLA breach prediction", weight: 7 },
    ],
    quarterly: [28, 45, 60, 73],
  },
  {
    id: "tenant_onboard",
    label: "Tenant Onboarding & Self-Service",
    icon: "🏢",
    color: "#E879F9",
    description:
      "Automated tenant provisioning, SharePoint/Power Automate workflows, space request approval, CSAT feedback loops",
    tasks: [
      { name: "Automated database provisioning", weight: 15 },
      { name: "Space request approval workflows", weight: 12 },
      { name: "Role & access provisioning", weight: 12 },
      { name: "SharePoint / Power Automate integration", weight: 10 },
      { name: "Self-service capacity portal", weight: 10 },
      { name: "Tenant health score automation", weight: 9 },
      { name: "Tenant onboarding checklist automation", weight: 8 },
      { name: "CSAT feedback collection & reporting", weight: 8 },
      { name: "SLA agreement auto-generation", weight: 8 },
      { name: "Offboarding & cleanup automation", weight: 8 },
    ],
    quarterly: [22, 38, 55, 68],
  },
];

// ─────────────────────────────────────────────
//  GROUP B — DBA OPERATIONS (new 8)
// ─────────────────────────────────────────────
export const DBA_DOMAINS = [
  {
    id: "backup_recovery",
    label: "Backup & Recovery Automation",
    icon: "🗄️",
    color: "#4ADE80",
    description:
      "Automated backup scheduling, completion verification, failure alerting, recovery point compliance, and restore testing",
    tasks: [
      { name: "Backup job scheduling & completion verification", weight: 20 },
      { name: "Backup failure alerting & retry logic", weight: 20 },
      { name: "RPO compliance monitoring & reporting", weight: 20 },
      { name: "Automated restore testing (synthetic recovery)", weight: 20 },
      { name: "Backup storage consumption trending", weight: 20 },
    ],
    quarterly: [10, 25, 42, 58],
  },
  {
    id: "user_session",
    label: "User & Session Management",
    icon: "👤",
    color: "#F59E0B",
    description:
      "Blocked session detection, zombie cleanup, logon failure alerting, concurrent session enforcement, inactive account management",
    tasks: [
      { name: "Blocked session detection & auto-kill with audit", weight: 20 },
      { name: "Zombie / orphaned session cleanup", weight: 20 },
      { name: "Logon failure spike detection & lockout alerting", weight: 20 },
      { name: "Concurrent session limit enforcement per profile", weight: 20 },
      { name: "Inactive account detection & suspension workflow", weight: 20 },
    ],
    quarterly: [15, 30, 48, 65],
  },
  {
    id: "object_maintenance",
    label: "Object Maintenance Automation",
    icon: "🔧",
    color: "#6EE7B7",
    description:
      "COLLECT STATS scheduling, fragmentation detection, temp table cleanup, dependency validation, unused object identification",
    tasks: [
      { name: "COLLECT STATS scheduling by row-change threshold", weight: 20 },
      { name: "Table fragmentation detection & reorg triggering", weight: 20 },
      { name: "Temp & volatile table cleanup monitoring", weight: 20 },
      { name: "View & macro dependency validation on schema change", weight: 20 },
      { name: "Unused object identification & archival recommendation", weight: 20 },
    ],
    quarterly: [20, 38, 55, 70],
  },
  {
    id: "compliance_audit",
    label: "Compliance & Audit Reporting",
    icon: "📋",
    color: "#C084FC",
    description:
      "PCI DSS evidence packs, privileged user activity reporting, SOX controls, data classification compliance, change freeze enforcement",
    tasks: [
      { name: "Automated PCI DSS evidence pack generation", weight: 20 },
      { name: "Privileged user activity reporting (DBC/DBADMIN)", weight: 20 },
      { name: "SOX control evidence generation per quarter", weight: 20 },
      { name: "Data classification tag compliance reporting", weight: 20 },
      { name: "Change freeze violation detection (DDL in blackout)", weight: 20 },
    ],
    quarterly: [10, 22, 40, 55],
  },
  {
    id: "job_workload",
    label: "Job & Workload Scheduling",
    icon: "🔁",
    color: "#FCA5A5",
    description:
      "ETL job failure detection, workload priority rule tuning, queue depth monitoring, job chain alerting, long-running job escalation",
    tasks: [
      { name: "ETL job failure detection & restart automation", weight: 20 },
      { name: "Workload priority rule tuning by time-of-day", weight: 20 },
      { name: "Job queue depth monitoring & throttle adjustment", weight: 20 },
      { name: "Dependent job chain failure propagation alerting", weight: 20 },
      { name: "Long-running job detection & escalation", weight: 20 },
    ],
    quarterly: [18, 35, 52, 68],
  },
  {
    id: "version_change",
    label: "Version Control & Change Management",
    icon: "📦",
    color: "#67E8F9",
    description:
      "DDL version control, change request linkage validation, pre-deployment impact analysis, post-deployment validation, rollback generation",
    tasks: [
      { name: "DDL version control check-in automation (Git)", weight: 20 },
      { name: "Change request linkage validation (DDL → CHG)", weight: 20 },
      { name: "Pre-deployment impact analysis (dependency graph)", weight: 20 },
      { name: "Post-deployment object validation (grants intact)", weight: 20 },
      { name: "Rollback script generation from DDL diff", weight: 20 },
    ],
    quarterly: [8, 20, 38, 52],
  },
  {
    id: "query_optimisation",
    label: "Query Optimisation Assistance",
    icon: "🧪",
    color: "#86EFAC",
    description:
      "Worst query identification, missing stats detection, skewed join alerting, full-table-scan alerting, AI-assisted rewrite suggestions",
    tasks: [
      { name: "Top-N worst query identification & weekly digest", weight: 20 },
      { name: "Missing / stale stats linked to slow queries", weight: 20 },
      { name: "Skewed join detection from explain plan parsing", weight: 20 },
      { name: "Product join & full-table-scan alerting per app", weight: 20 },
      { name: "Query rewrite suggestion engine (AI-assisted)", weight: 20 },
    ],
    quarterly: [12, 28, 45, 60],
  },
  {
    id: "crossplatform_health",
    label: "Cross-Platform Integration Health",
    icon: "🌐",
    color: "#FCD34D",
    description:
      "QueryGrid latency monitoring, JDBC/ODBC pool alerting, Ab Initio load tracking, BigQuery federated query performance, data sync lag",
    tasks: [
      { name: "QueryGrid link latency & error rate monitoring", weight: 20 },
      { name: "JDBC / ODBC connection pool exhaustion alerting", weight: 20 },
      { name: "Ab Initio → Teradata load job success rate tracking", weight: 20 },
      { name: "BigQuery federated query performance trending", weight: 20 },
      { name: "Data sync lag monitoring between platforms", weight: 20 },
    ],
    quarterly: [15, 32, 50, 65],
  },
];

// Combined export used by the dashboard
export const AUTOMATION_AREAS = [...PLATFORM_DOMAINS, ...DBA_DOMAINS];
