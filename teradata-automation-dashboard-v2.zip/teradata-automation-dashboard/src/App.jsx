import { useState, useMemo } from "react";
import { PLATFORM_DOMAINS, DBA_DOMAINS, AUTOMATION_AREAS, QUARTERS } from "./data";
import RadialGauge from "./components/RadialGauge";
import QuarterTrend from "./components/QuarterTrend";
import MiniBar from "./components/MiniBar";
import "./App.css";

const GROUPS = [
  { key: "all",      label: "All Domains",       domains: AUTOMATION_AREAS },
  { key: "platform", label: "Platform Operations", domains: PLATFORM_DOMAINS },
  { key: "dba",      label: "DBA Operations",     domains: DBA_DOMAINS },
];

export default function App() {
  const [selectedQ,   setSelectedQ]   = useState(3);
  const [expandedId,  setExpandedId]  = useState(null);
  const [view,        setView]        = useState("grid");   // "grid" | "table"
  const [group,       setGroup]       = useState("all");
  const [search,      setSearch]      = useState("");

  const activeDomains = useMemo(() => {
    const base = GROUPS.find(g => g.key === group)?.domains ?? AUTOMATION_AREAS;
    if (!search.trim()) return base;
    const q = search.toLowerCase();
    return base.filter(
      d => d.label.toLowerCase().includes(q) ||
           d.description.toLowerCase().includes(q) ||
           d.tasks.some(t => t.name.toLowerCase().includes(q))
    );
  }, [group, search]);

  const sorted = useMemo(
    () => [...activeDomains].sort((a, b) => b.quarterly[selectedQ] - a.quarterly[selectedQ]),
    [activeDomains, selectedQ]
  );

  const overallAvg = activeDomains.length
    ? Math.round(activeDomains.reduce((s, a) => s + a.quarterly[selectedQ], 0) / activeDomains.length)
    : 0;
  const overallColor = overallAvg >= 70 ? "#34D399" : overallAvg >= 40 ? "#FBBF24" : "#F87171";

  const totalTasks = activeDomains.reduce((s, a) => s + a.tasks.length, 0);

  return (
    <div className="app">
      {/* ── HEADER ── */}
      <header className="header">
        <div className="header-top">
          <div className="header-title-block">
            <span className="eyebrow">Teradata Data Platform</span>
            <h1>Automation Coverage Report</h1>
            <p className="subtitle">
              16 domains · Platform Operations &amp; DBA Operations · Quarterly reporting
            </p>
          </div>

          <div className="overall-score-card">
            <RadialGauge value={overallAvg} color={overallColor} size={72} />
            <div>
              <div className="label-xs">Overall Coverage</div>
              <div className="label-sm">{QUARTERS[selectedQ]}</div>
              <div className="label-xs muted" style={{ marginTop: 4 }}>
                {activeDomains.length} domains · {totalTasks} tasks
              </div>
            </div>
          </div>
        </div>

        {/* Controls row */}
        <div className="header-controls">
          <div className="controls-left">
            {/* Group filter */}
            <div className="group-tabs">
              {GROUPS.map(g => (
                <button
                  key={g.key}
                  className={`group-tab ${group === g.key ? "active" : ""}`}
                  onClick={() => { setGroup(g.key); setExpandedId(null); }}
                >
                  {g.label}
                  <span className="tab-count">{g.domains.length}</span>
                </button>
              ))}
            </div>

            {/* Quarter tabs */}
            <div className="quarter-tabs">
              {QUARTERS.map((q, i) => (
                <button
                  key={q}
                  className={`quarter-tab ${selectedQ === i ? "active" : ""}`}
                  onClick={() => setSelectedQ(i)}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          <div className="controls-right">
            {/* Search */}
            <input
              className="search-input"
              placeholder="Search domains or tasks…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />

            {/* View toggle */}
            <div className="view-toggle">
              <button className={`view-btn ${view === "grid"  ? "active" : ""}`} onClick={() => setView("grid")}>🔲 Cards</button>
              <button className={`view-btn ${view === "table" ? "active" : ""}`} onClick={() => setView("table")}>📋 Table</button>
            </div>
          </div>
        </div>
      </header>

      {/* ── MAIN ── */}
      <main className="main">

        {/* Summary strip */}
        <div className="summary-bar">
          <span className="label-xs muted" style={{ whiteSpace: "nowrap" }}>Coverage</span>
          <div className="stacked-bar">
            {activeDomains.map(a => (
              <div
                key={a.id}
                className="stacked-segment"
                title={`${a.label}: ${a.quarterly[selectedQ]}%`}
                style={{ flex: 1, background: a.color + "28" }}
              >
                <div className="stacked-fill" style={{ width: `${a.quarterly[selectedQ]}%`, background: a.color }} />
              </div>
            ))}
          </div>
          <div className="legend">
            {[["🟢","≥70%","#34D399"],["🟡","40–69%","#FBBF24"],["🔴","<40%","#F87171"]].map(([e,l,c]) => (
              <span key={l} style={{ color: c }} className="legend-item">{e} {l}</span>
            ))}
          </div>
        </div>

        {/* Category labels when showing all */}
        {group === "all" && view === "grid" && (
          <>
            <SectionHeading label="Platform Operations" count={PLATFORM_DOMAINS.length} color="#00C2FF" />
            <div className="card-grid" style={{ marginBottom: 28 }}>
              {sorted
                .filter(a => PLATFORM_DOMAINS.some(d => d.id === a.id))
                .map(area => (
                  <AreaCard
                    key={area.id}
                    area={area}
                    selectedQ={selectedQ}
                    expandedId={expandedId}
                    setExpandedId={setExpandedId}
                  />
                ))}
            </div>
            <SectionHeading label="DBA Operations" count={DBA_DOMAINS.length} color="#4ADE80" />
            <div className="card-grid">
              {sorted
                .filter(a => DBA_DOMAINS.some(d => d.id === a.id))
                .map(area => (
                  <AreaCard
                    key={area.id}
                    area={area}
                    selectedQ={selectedQ}
                    expandedId={expandedId}
                    setExpandedId={setExpandedId}
                  />
                ))}
            </div>
          </>
        )}

        {/* Single group grid */}
        {group !== "all" && view === "grid" && (
          <div className="card-grid">
            {sorted.map(area => (
              <AreaCard
                key={area.id}
                area={area}
                selectedQ={selectedQ}
                expandedId={expandedId}
                setExpandedId={setExpandedId}
              />
            ))}
          </div>
        )}

        {/* TABLE VIEW */}
        {view === "table" && (
          <DataTable
            sorted={sorted}
            selectedQ={selectedQ}
            allDomains={activeDomains}
            showGroup={group === "all"}
          />
        )}

        {/* Scoring legend */}
        <div className="scoring-legend">
          <div className="label-xs muted" style={{ marginBottom: 10 }}>How to Score</div>
          <div className="legend-grid">
            {[
              ["Weighted Tasks",     "Each task has a priority weight. Score = Σ(completed weights) / Σ(total weights) × 100"],
              ["Quarterly Cadence",  "Score locked & reported per quarter. Delta shows QoQ improvement velocity."],
              ["Status Thresholds",  "🟢 ≥70% Optimised · 🟡 40–69% In Progress · 🔴 <40% Early Stage"],
              ["16 Domains",         "8 Platform Operations + 8 DBA Operations — filter by group using the tabs above"],
            ].map(([t,d]) => (
              <div key={t} className="legend-entry">
                <div className="legend-entry-title">{t}</div>
                <div className="legend-entry-desc">{d}</div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

/* ── Section heading ── */
function SectionHeading({ label, count, color }) {
  return (
    <div className="section-heading">
      <div className="section-rule" style={{ background: color }} />
      <span className="section-label">{label}</span>
      <span className="section-count" style={{ color }}>{count} domains</span>
    </div>
  );
}

/* ── Area card ── */
function AreaCard({ area, selectedQ, expandedId, setExpandedId }) {
  const pct         = area.quarterly[selectedQ];
  const statusColor = pct >= 70 ? "#34D399" : pct >= 40 ? "#FBBF24" : "#F87171";
  const isOpen      = expandedId === area.id;
  const delta       = selectedQ > 0 ? pct - area.quarterly[selectedQ - 1] : null;

  return (
    <div
      className={`area-card ${isOpen ? "open" : ""}`}
      style={{ "--accent": area.color }}
    >
      <div className="card-header" onClick={() => setExpandedId(isOpen ? null : area.id)}>
        <div className="area-icon" style={{ background: area.color + "15", border: `1px solid ${area.color}33` }}>
          {area.icon}
        </div>
        <div className="card-body">
          <div className="card-title-row">
            <h3 className="card-title">{area.label}</h3>
            <RadialGauge value={pct} color={statusColor} size={52} />
          </div>
          <p className="card-desc">{area.description}</p>
          <div className="card-footer-row">
            <div>
              <div className="label-xs muted trend-label">Trend</div>
              <QuarterTrend data={area.quarterly} color={area.color} />
            </div>
            <div className="delta-block">
              <div className="label-xs muted">QoQ Δ</div>
              <div className="delta-value" style={{ color: delta > 0 ? "#34D399" : "#94a3b8" }}>
                {delta !== null ? `+${delta}%` : "—"}
              </div>
            </div>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="task-list" style={{ borderColor: area.color + "22" }}>
          <div className="label-xs muted task-list-heading">
            Automation Tasks · Weighted by Priority
          </div>
          {area.tasks.map((t, i) => {
            const taskPct = Math.min(100, Math.round(pct * (0.6 + (i % 5) * 0.1)));
            return (
              <div key={i} className="task-row">
                <div className="task-name-row">
                  <span className="task-name">{t.name}</span>
                  <span className="task-weight label-xs muted">w:{t.weight}</span>
                </div>
                <MiniBar value={taskPct} color={area.color} />
              </div>
            );
          })}
          <div className="task-score-footer" style={{ background: area.color + "10", border: `1px solid ${area.color}22`, color: area.color }}>
            WEIGHTED SCORE: {pct}% · {area.tasks.length} tasks · Next target: {Math.min(100, pct + 15)}%
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Data table ── */
function DataTable({ sorted, selectedQ, allDomains, showGroup }) {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th className="th-left" colSpan={2}>Domain</th>
            {showGroup && <th className="th-left">Group</th>}
            {QUARTERS.map((q, i) => (
              <th key={q} className={`th-center ${selectedQ === i ? "th-selected" : ""}`}>{q}</th>
            ))}
            <th className="th-center">QoQ Δ</th>
            <th className="th-center">Trend</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((area, idx) => {
            const pct         = area.quarterly[selectedQ];
            const statusColor = pct >= 70 ? "#34D399" : pct >= 40 ? "#FBBF24" : "#F87171";
            const delta       = selectedQ > 0 ? pct - area.quarterly[selectedQ - 1] : null;
            const isDba       = DBA_DOMAINS.some(d => d.id === area.id);
            return (
              <tr key={area.id} className={`data-row ${idx % 2 === 0 ? "even" : "odd"}`}>
                <td className="icon-cell">{area.icon}</td>
                <td className="name-cell">
                  <div className="row-name">{area.label}</div>
                  <div className="row-sub label-xs muted">{area.tasks.length} tasks</div>
                </td>
                {showGroup && (
                  <td className="name-cell">
                    <span style={{
                      fontSize: 10, fontFamily: "DM Mono, monospace",
                      padding: "2px 7px", borderRadius: 10,
                      background: isDba ? "#4ADE8018" : "#00C2FF18",
                      color: isDba ? "#4ADE80" : "#00C2FF",
                      border: `1px solid ${isDba ? "#4ADE8033" : "#00C2FF33"}`,
                    }}>
                      {isDba ? "DBA Ops" : "Platform"}
                    </span>
                  </td>
                )}
                {area.quarterly.map((q, qi) => (
                  <td key={qi} className="pct-cell">
                    <span
                      className={`pct-badge ${qi === selectedQ ? "pct-badge--active" : ""}`}
                      style={qi === selectedQ ? { background: statusColor + "20", borderColor: statusColor + "44", color: statusColor } : {}}
                    >{q}%</span>
                  </td>
                ))}
                <td className="pct-cell">
                  <span className="delta-badge" style={{ color: delta > 0 ? "#34D399" : "#64748b" }}>
                    {delta !== null ? `+${delta}%` : "—"}
                  </span>
                </td>
                <td className="trend-cell">
                  <QuarterTrend data={area.quarterly} color={area.color} />
                </td>
              </tr>
            );
          })}
        </tbody>
        <tfoot>
          <tr className="footer-row">
            <td colSpan={showGroup ? 3 : 2} className="footer-label">Platform Average ({allDomains.length} domains)</td>
            {QUARTERS.map((_, qi) => {
              const avg = Math.round(allDomains.reduce((s, a) => s + a.quarterly[qi], 0) / allDomains.length);
              return (
                <td key={qi} className="pct-cell footer-avg">
                  <span style={{ color: qi === selectedQ ? "#60a5fa" : "#475569" }}>{avg}%</span>
                </td>
              );
            })}
            <td className="pct-cell footer-avg">
              <span style={{ color: "#34D399" }}>
                {selectedQ > 0
                  ? `+${Math.round(allDomains.reduce((s,a) => s + a.quarterly[selectedQ] - a.quarterly[selectedQ-1], 0) / allDomains.length)}% avg`
                  : "—"}
              </span>
            </td>
            <td />
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
