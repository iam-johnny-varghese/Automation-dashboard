import { useState } from "react";
import { AUTOMATION_AREAS, QUARTERS } from "./data";
import RadialGauge from "./components/RadialGauge";
import QuarterTrend from "./components/QuarterTrend";
import MiniBar from "./components/MiniBar";
import "./App.css";

export default function App() {
  const [selectedQ, setSelectedQ] = useState(3);
  const [expandedId, setExpandedId] = useState(null);
  const [view, setView] = useState("grid"); // "grid" | "table"

  const overallAvg = Math.round(
    AUTOMATION_AREAS.reduce((s, a) => s + a.quarterly[selectedQ], 0) /
      AUTOMATION_AREAS.length
  );

  const overallColor =
    overallAvg >= 70 ? "#34D399" : overallAvg >= 40 ? "#FBBF24" : "#F87171";

  const sorted = [...AUTOMATION_AREAS].sort(
    (a, b) => b.quarterly[selectedQ] - a.quarterly[selectedQ]
  );

  return (
    <div className="app">
      {/* ── HEADER ── */}
      <header className="header">
        <div className="header-top">
          <div className="header-title-block">
            <span className="eyebrow">Teradata Data Platform</span>
            <h1>Automation Coverage Report</h1>
            <p className="subtitle">
              Track &amp; report platform automation maturity across all
              operational domains
            </p>
          </div>

          <div className="overall-score-card">
            <RadialGauge value={overallAvg} color={overallColor} size={72} />
            <div>
              <div className="label-xs">Overall Coverage</div>
              <div className="label-sm">{QUARTERS[selectedQ]}</div>
              <div className="label-xs muted" style={{ marginTop: 4 }}>
                {AUTOMATION_AREAS.length} domains ·{" "}
                {AUTOMATION_AREAS.reduce((s, a) => s + a.tasks.length, 0)} tasks
              </div>
            </div>
          </div>
        </div>

        <div className="header-controls">
          {/* Quarter tabs */}
          <div className="quarter-tabs">
            {QUARTERS.map((q, i) => (
              <button
                key={q}
                className={`quarter-tab ${selectedQ === i ? "active" : ""}`}
                onClick={() => setSelectedQ(i)}
              >
                {q}
              </button>
            ))}
          </div>

          {/* View toggle */}
          <div className="view-toggle">
            <button
              className={`view-btn ${view === "grid" ? "active" : ""}`}
              onClick={() => setView("grid")}
            >
              🔲 Cards
            </button>
            <button
              className={`view-btn ${view === "table" ? "active" : ""}`}
              onClick={() => setView("table")}
            >
              📋 Table
            </button>
          </div>
        </div>
      </header>

      {/* ── MAIN ── */}
      <main className="main">
        {/* Summary bar */}
        <div className="summary-bar">
          <span className="label-xs muted">Coverage Breakdown</span>
          <div className="stacked-bar">
            {AUTOMATION_AREAS.map((a) => (
              <div
                key={a.id}
                className="stacked-segment"
                title={`${a.label}: ${a.quarterly[selectedQ]}%`}
                style={{ flex: 1, background: a.color + "33" }}
              >
                <div
                  className="stacked-fill"
                  style={{
                    width: `${a.quarterly[selectedQ]}%`,
                    background: a.color,
                  }}
                />
              </div>
            ))}
          </div>
          <div className="legend">
            {[
              ["🟢", "≥70%", "#34D399"],
              ["🟡", "40–69%", "#FBBF24"],
              ["🔴", "<40%", "#F87171"],
            ].map(([e, l, c]) => (
              <span key={l} style={{ color: c }} className="legend-item">
                {e} {l}
              </span>
            ))}
          </div>
        </div>

        {/* ── GRID ── */}
        {view === "grid" && (
          <div className="card-grid">
            {sorted.map((area) => {
              const pct = area.quarterly[selectedQ];
              const statusColor =
                pct >= 70 ? "#34D399" : pct >= 40 ? "#FBBF24" : "#F87171";
              const isOpen = expandedId === area.id;
              const delta =
                selectedQ > 0
                  ? pct - area.quarterly[selectedQ - 1]
                  : null;

              return (
                <div
                  key={area.id}
                  className={`area-card ${isOpen ? "open" : ""}`}
                  style={{ "--accent": area.color }}
                >
                  {/* Card header */}
                  <div
                    className="card-header"
                    onClick={() =>
                      setExpandedId(isOpen ? null : area.id)
                    }
                  >
                    <div
                      className="area-icon"
                      style={{
                        background: area.color + "15",
                        border: `1px solid ${area.color}33`,
                      }}
                    >
                      {area.icon}
                    </div>

                    <div className="card-body">
                      <div className="card-title-row">
                        <h3 className="card-title">{area.label}</h3>
                        <RadialGauge
                          value={pct}
                          color={statusColor}
                          size={52}
                        />
                      </div>
                      <p className="card-desc">{area.description}</p>

                      <div className="card-footer-row">
                        <div>
                          <div className="label-xs muted trend-label">
                            Trend
                          </div>
                          <QuarterTrend
                            data={area.quarterly}
                            color={area.color}
                          />
                        </div>
                        <div className="delta-block">
                          <div className="label-xs muted">QoQ Δ</div>
                          <div
                            className="delta-value"
                            style={{
                              color:
                                delta > 0 ? "#34D399" : "#94a3b8",
                            }}
                          >
                            {delta !== null ? `+${delta}%` : "—"}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Expanded task list */}
                  {isOpen && (
                    <div
                      className="task-list"
                      style={{ borderColor: area.color + "22" }}
                    >
                      <div className="label-xs muted task-list-heading">
                        Automation Tasks · Weighted by Priority
                      </div>
                      {area.tasks.map((t, i) => {
                        const taskPct = Math.min(
                          100,
                          Math.round(pct * (0.6 + (i % 4) * 0.12))
                        );
                        return (
                          <div key={i} className="task-row">
                            <div className="task-name-row">
                              <span className="task-name">{t.name}</span>
                              <span className="task-weight label-xs muted">
                                w:{t.weight}
                              </span>
                            </div>
                            <MiniBar value={taskPct} color={area.color} />
                          </div>
                        );
                      })}
                      <div
                        className="task-score-footer"
                        style={{
                          background: area.color + "10",
                          border: `1px solid ${area.color}22`,
                          color: area.color,
                        }}
                      >
                        WEIGHTED SCORE: {pct}% · {area.tasks.length} tasks
                        · Next target: {Math.min(100, pct + 15)}%
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ── TABLE ── */}
        {view === "table" && (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th className="th-left" colSpan={2}>
                    Domain
                  </th>
                  {QUARTERS.map((q, i) => (
                    <th
                      key={q}
                      className={`th-center ${
                        selectedQ === i ? "th-selected" : ""
                      }`}
                    >
                      {q}
                    </th>
                  ))}
                  <th className="th-center">QoQ Δ</th>
                  <th className="th-center">Trend</th>
                </tr>
              </thead>
              <tbody>
                {AUTOMATION_AREAS.map((area, idx) => {
                  const pct = area.quarterly[selectedQ];
                  const statusColor =
                    pct >= 70
                      ? "#34D399"
                      : pct >= 40
                      ? "#FBBF24"
                      : "#F87171";
                  const delta =
                    selectedQ > 0
                      ? pct - area.quarterly[selectedQ - 1]
                      : null;
                  return (
                    <tr
                      key={area.id}
                      className={`data-row ${idx % 2 === 0 ? "even" : "odd"}`}
                    >
                      <td className="icon-cell">{area.icon}</td>
                      <td className="name-cell">
                        <div className="row-name">{area.label}</div>
                        <div className="row-sub label-xs muted">
                          {area.tasks.length} tasks
                        </div>
                      </td>
                      {area.quarterly.map((q, qi) => (
                        <td key={qi} className="pct-cell">
                          <span
                            className={`pct-badge ${
                              qi === selectedQ ? "pct-badge--active" : ""
                            }`}
                            style={
                              qi === selectedQ
                                ? {
                                    background: statusColor + "20",
                                    borderColor: statusColor + "44",
                                    color: statusColor,
                                  }
                                : {}
                            }
                          >
                            {q}%
                          </span>
                        </td>
                      ))}
                      <td className="pct-cell">
                        <span
                          className="delta-badge"
                          style={{
                            color: delta > 0 ? "#34D399" : "#64748b",
                          }}
                        >
                          {delta !== null ? `+${delta}%` : "—"}
                        </span>
                      </td>
                      <td className="trend-cell">
                        <QuarterTrend
                          data={area.quarterly}
                          color={area.color}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="footer-row">
                  <td colSpan={2} className="footer-label">
                    Platform Average
                  </td>
                  {QUARTERS.map((_, qi) => {
                    const avg = Math.round(
                      AUTOMATION_AREAS.reduce(
                        (s, a) => s + a.quarterly[qi],
                        0
                      ) / AUTOMATION_AREAS.length
                    );
                    return (
                      <td key={qi} className="pct-cell footer-avg">
                        <span
                          style={{
                            color: qi === selectedQ ? "#60a5fa" : "#475569",
                          }}
                        >
                          {avg}%
                        </span>
                      </td>
                    );
                  })}
                  <td className="pct-cell footer-avg">
                    <span style={{ color: "#34D399" }}>
                      {selectedQ > 0
                        ? `+${Math.round(
                            AUTOMATION_AREAS.reduce(
                              (s, a) =>
                                s +
                                a.quarterly[selectedQ] -
                                a.quarterly[selectedQ - 1],
                              0
                            ) / AUTOMATION_AREAS.length
                          )}% avg`
                        : "—"}
                    </span>
                  </td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
        )}

        {/* Scoring legend */}
        <div className="scoring-legend">
          <div className="label-xs muted" style={{ marginBottom: 10 }}>
            How to Score
          </div>
          <div className="legend-grid">
            {[
              [
                "Weighted Tasks",
                "Each task has a priority weight (7–15). Score = Σ(completed_weight) / Σ(total_weight) × 100",
              ],
              [
                "Quarterly Cadence",
                "Score is locked & reported per quarter. Delta shows QoQ improvement velocity.",
              ],
              [
                "Status Thresholds",
                "🟢 ≥70% Optimized · 🟡 40–69% In Progress · 🔴 <40% Early Stage",
              ],
            ].map(([title, desc]) => (
              <div key={title} className="legend-entry">
                <div className="legend-entry-title">{title}</div>
                <div className="legend-entry-desc">{desc}</div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
