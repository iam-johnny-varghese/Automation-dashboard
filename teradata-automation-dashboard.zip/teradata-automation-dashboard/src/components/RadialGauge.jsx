/**
 * RadialGauge
 * Props:
 *   value  {number}  0–100
 *   color  {string}  hex color for the arc
 *   size   {number}  svg dimensions (default 80)
 */
export default function RadialGauge({ value, color, size = 80 }) {
  const r = 28;
  const circ = 2 * Math.PI * r;
  const dash = (value / 100) * circ;

  return (
    <svg width={size} height={size} viewBox="0 0 80 80">
      {/* Track */}
      <circle
        cx="40"
        cy="40"
        r={r}
        fill="none"
        stroke="#1e293b"
        strokeWidth="8"
      />
      {/* Progress arc */}
      <circle
        cx="40"
        cy="40"
        r={r}
        fill="none"
        stroke={color}
        strokeWidth="8"
        strokeDasharray={`${dash} ${circ}`}
        strokeLinecap="round"
        transform="rotate(-90 40 40)"
        style={{ transition: "stroke-dasharray 0.8s ease" }}
      />
      {/* Label */}
      <text
        x="40"
        y="44"
        textAnchor="middle"
        fill="white"
        fontSize="13"
        fontWeight="700"
        fontFamily="'DM Mono', monospace"
      >
        {value}%
      </text>
    </svg>
  );
}
