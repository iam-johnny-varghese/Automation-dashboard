/**
 * QuarterTrend
 * Renders a small SVG sparkline for quarterly data.
 * Props:
 *   data   {number[]}  array of 4 percentage values
 *   color  {string}    hex color for the line & dots
 */
export default function QuarterTrend({ data, color }) {
  const max = 100;
  const h = 36;
  const w = 120;

  const points = data
    .map((v, i) => `${(i / (data.length - 1)) * w},${h - (v / max) * h}`)
    .join(" ");

  return (
    <svg width={w} height={h} style={{ overflow: "visible" }}>
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinejoin="round"
      />
      {data.map((v, i) => (
        <circle
          key={i}
          cx={(i / (data.length - 1)) * w}
          cy={h - (v / max) * h}
          r="3"
          fill={color}
        />
      ))}
    </svg>
  );
}
