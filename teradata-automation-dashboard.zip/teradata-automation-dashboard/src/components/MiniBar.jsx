/**
 * MiniBar
 * A small horizontal progress bar used in the expanded task list.
 * Props:
 *   value  {number}  0–100
 *   color  {string}  hex fill color
 */
export default function MiniBar({ value, color }) {
  return (
    <div className="mini-bar-wrap">
      <div className="mini-bar-track">
        <div
          className="mini-bar-fill"
          style={{ width: `${value}%`, background: color }}
        />
      </div>
      <span className="mini-bar-label">{value}%</span>
    </div>
  );
}
