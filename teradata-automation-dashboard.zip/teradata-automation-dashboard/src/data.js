export const QUARTERS = ["Q1 2025", "Q2 2025", "Q3 2025", "Q4 2025"];

/**
 * AUTOMATION_AREAS
 * Each area has:
 *   - id          : unique key
 *   - label       : display name
 *   - icon        : emoji icon
 *   - color       : hex accent color
 *   - description : short summary of what the area covers
 *   - tasks       : list of { name, weight } (weight 7–15, higher = more impactful)
 *   - quarterly   : [Q1%, Q2%, Q3%, Q4%] — update these each quarter
 *
 * SCORING FORMULA:
 *   coverage% = Σ(completed task weights) / Σ(all task weights) × 100
 *
 * UPDATE INSTRUCTIONS (every quarter):
 *   1. Mark each task as complete/incomplete in your tracker
 *   2. Sum weights of completed tasks per area
 *   3. Divide by total weights for that area × 100
 *   4. Update the quarterly array for the new quarter column
 */
export const AUTOMATION_AREAS = [
  {
    id: "perf_obs",
    label: "Performance Monitoring & Observability",
    icon: "📊",
    color: "#00C2FF",
    description:
      "DBQL anomaly detection, workload monitoring, query performance alerting, SLA breach detection, real-time dashboards",
    tasks: [
      { name: "DBQL ingestion & anomaly detection", weight: 15 },
      { name: "Workload & concurrency monitoring", weight: 12 },
      { name: "SLA breach alerting (ServiceNow)", weight: 12 },
      { name: "Real-time performance dashboards", weight: 10 },
      { name: "Historical trend reporting", weight: 8 },
      { name: "Query classification & tagging", weight: 8 },
      { name: "Active session & blocking detection", weight: 10 },
      { name: "Node / vproc health checks", weight: 10 },
      { name: "Skew & spool monitoring", weight: 8 },
      { name: "Automated explain plan analysis", weight: 7 },
    ],
    quarterly: [35, 52, 68, 80],
  },
  {
    id: "security_gov",
    label: "Security & Governance Automation",
    icon: "🔐",
    color: "#A78BFA",
    description:
      "PCI zone enforcement, Secure Zone provisioning, access log behavioral analytics, role provisioning, audit reporting",
    tasks: [
      { name: "Secure Zone provisioning & validation", weight: 15 },
      { name: "PCI zone isolation enforcement", weight: 12 },
      { name: "Access log behavioral anomaly detection", weight: 12 },
      { name: "Role & profile automated provisioning", weight: 10 },
      { name: "Quarterly access certification reports", weight: 8 },
      { name: "Creator rights governance checks", weight: 8 },
      { name: "Password & logon policy auditing", weight: 8 },
      { name: "DBC.LogonOff / AccessLog alerting", weight: 10 },
      { name: "DDL change audit trail", weight: 9 },
      { name: "UDF protected mode enforcement", weight: 8 },
    ],
    quarterly: [20, 38, 55, 70],
  },
  {
    id: "infra_deploy",
    label: "Infrastructure & Deployment Automation",
    icon: "⚙️",
    color: "#34D399",
    description:
      "Environment provisioning, schema deployment pipelines, QueryGrid config, release management, config-as-code",
    tasks: [
      { name: "Schema & object deployment pipelines", weight: 15 },
      { name: "QueryGrid connector provisioning", weight: 12 },
      { name: "Environment baseline config-as-code", weight: 12 },
      { name: "Release management & rollback scripts", weight: 10 },
      { name: "TD system parameter drift detection", weight: 8 },
      { name: "Automated regression test suites", weight: 10 },
      { name: "Service account provisioning", weight: 10 },
      { name: "Space quota allocation automation", weight: 8 },
      { name: "Multi-environment promotion workflows", weight: 8 },
      { name: "DR failover readiness checks", weight: 7 },
    ],
    quarterly: [25, 40, 58, 72],
  },
  {
    id: "capacity_mgmt",
    label: "Capacity Management & Forecasting",
    icon: "📈",
    color: "#FBBF24",
    description:
      "Prophet/ML forecasting, perm space trending, AWT pool analysis, inorganic growth modeling, ServiceNow capacity alerts",
    tasks: [
      { name: "Perm space trending & forecasting", weight: 15 },
      { name: "ML ensemble capacity models (Prophet/XGB)", weight: 15 },
      { name: "AWT pool utilization analysis", weight: 10 },
      { name: "Inorganic growth event modeling", weight: 8 },
      { name: "Capacity threshold alerting", weight: 10 },
      { name: "ServiceNow capacity incident creation", weight: 8 },
      { name: "Tenant-level space attribution", weight: 10 },
      { name: "CPU / IO saturation forecasting", weight: 8 },
      { name: "Growth recommendation engine", weight: 8 },
      { name: "Executive capacity reports", weight: 8 },
    ],
    quarterly: [40, 60, 75, 85],
  },
  {
    id: "data_lifecycle",
    label: "Data Lifecycle & Quality Automation",
    icon: "🔄",
    color: "#F87171",
    description:
      "Data retention enforcement, archival pipelines, lineage tracking, redundancy detection, data quality rule automation",
    tasks: [
      { name: "Retention policy enforcement", weight: 12 },
      { name: "Automated archival & purge pipelines", weight: 12 },
      { name: "Data lineage graph generation", weight: 15 },
      { name: "Redundancy & duplication detection", weight: 12 },
      { name: "Data quality rule automation", weight: 10 },
      { name: "Stale object detection & cleanup", weight: 8 },
      { name: "Partition elimination validation", weight: 8 },
      { name: "Stats freshness monitoring", weight: 8 },
      { name: "Schema drift detection", weight: 8 },
      { name: "Cross-platform lineage (TD↔BQ↔Hadoop)", weight: 7 },
    ],
    quarterly: [15, 30, 48, 62],
  },
  {
    id: "cost_finops",
    label: "Cost Visibility & FinOps Automation",
    icon: "💰",
    color: "#38BDF8",
    description:
      "Cost-per-query attribution, tenant chargeback, FinOps dashboards, Cloudability/Apptio integration, workload cost tagging",
    tasks: [
      { name: "Cost-per-query attribution engine", weight: 15 },
      { name: "Tenant chargeback reporting", weight: 15 },
      { name: "FinOps executive dashboards", weight: 10 },
      { name: "Workload cost tagging & classification", weight: 10 },
      { name: "GCP BigQuery cost integration", weight: 8 },
      { name: "Cloudability / Apptio data feeds", weight: 8 },
      { name: "Cost anomaly alerting", weight: 10 },
      { name: "Idle resource detection", weight: 8 },
      { name: "Cross-platform cost normalization", weight: 8 },
      { name: "Automated cost optimization recommendations", weight: 8 },
    ],
    quarterly: [30, 48, 62, 75],
  },
  {
    id: "incident_ops",
    label: "Incident Management & AIOps",
    icon: "🚨",
    color: "#FB923C",
    description:
      "ServiceNow incident auto-creation, MTTR tracking, runbook automation, alert correlation, on-call routing",
    tasks: [
      { name: "Automated incident creation (ServiceNow)", weight: 15 },
      { name: "MTTR / DORA metrics tracking", weight: 12 },
      { name: "Alert correlation & deduplication", weight: 12 },
      { name: "Runbook automation execution", weight: 12 },
      { name: "On-call routing & escalation", weight: 8 },
      { name: "Post-incident report generation", weight: 8 },
      { name: "Problem record linkage", weight: 8 },
      { name: "Change-to-incident correlation", weight: 8 },
      { name: "Root cause suggestion (AI-assisted)", weight: 10 },
      { name: "SLA breach prediction", weight: 7 },
    ],
    quarterly: [28, 45, 60, 73],
  },
  {
    id: "tenant_onboard",
    label: "Tenant Onboarding & Self-Service",
    icon: "🏢",
    color: "#E879F9",
    description:
      "Automated tenant provisioning, SharePoint/Power Automate workflows, space request approval, CSAT feedback loops",
    tasks: [
      { name: "Automated database provisioning", weight: 15 },
      { name: "Space request approval workflows", weight: 12 },
      { name: "Role & access provisioning", weight: 12 },
      { name: "SharePoint / Power Automate integration", weight: 10 },
      { name: "Self-service capacity portal", weight: 10 },
      { name: "Tenant onboarding checklist automation", weight: 8 },
      { name: "CSAT feedback collection & reporting", weight: 8 },
      { name: "SLA agreement auto-generation", weight: 8 },
      { name: "Tenant health score automation", weight: 9 },
      { name: "Offboarding & cleanup automation", weight: 8 },
    ],
    quarterly: [22, 38, 55, 68],
  },
];
