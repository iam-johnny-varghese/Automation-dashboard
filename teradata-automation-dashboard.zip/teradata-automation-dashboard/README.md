# Teradata Platform Automation Coverage Dashboard

A React dashboard for tracking and reporting automation maturity across all
Teradata data platform operational domains — updated and published every quarter.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server (opens at http://localhost:3000)
npm run dev

# 3. Build for production
npm run build
```

---

## 📁 Project Structure

```
teradata-automation-dashboard/
├── index.html                  # App shell
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx                # React entry point
    ├── App.jsx                 # Main dashboard layout & logic
    ├── App.css                 # All styles
    ├── data.js                 # ← EDIT THIS every quarter
    └── components/
        ├── RadialGauge.jsx     # SVG donut gauge
        ├── QuarterTrend.jsx    # SVG sparkline
        └── MiniBar.jsx         # Horizontal progress bar
```

---

## 📊 Automation Domains

| Icon | Domain                                | Key Capabilities |
|------|---------------------------------------|------------------|
| 📊   | Performance Monitoring & Observability | DBQL, workload, SLA alerting |
| 🔐   | Security & Governance                 | PCI, Secure Zones, access logs |
| ⚙️   | Infrastructure & Deployment           | Pipelines, QueryGrid, config-as-code |
| 📈   | Capacity Management & Forecasting     | Prophet/ML, AWT, ServiceNow |
| 🔄   | Data Lifecycle & Quality              | Lineage, retention, redundancy |
| 💰   | Cost Visibility & FinOps              | Chargeback, attribution, FinOps |
| 🚨   | Incident Management & AIOps           | ServiceNow, MTTR/DORA, runbooks |
| 🏢   | Tenant Onboarding & Self-Service      | Provisioning, approvals, CSAT |

---

## 🔢 Scoring Methodology

### Formula

```
Coverage % = Σ(completed task weights) / Σ(all task weights) × 100
```

Each task has a **priority weight (7–15)**:
- **15** = High-impact foundation capability
- **10–12** = Core operational automation
- **7–9** = Supporting / enhancement task

### Status Thresholds

| Range     | Status      | Meaning                          |
|-----------|-------------|----------------------------------|
| ≥ 70%     | 🟢 Optimized | Fully automated, running in prod |
| 40–69%    | 🟡 In Progress | Partially automated, active work |
| < 40%     | 🔴 Early Stage | Planned or just started          |

---

## 📅 Quarterly Update Process

### Step 1 — Run your task checklist

For each domain, go through `src/data.js` and mark which tasks are complete.

### Step 2 — Calculate coverage %

```
Example: Security & Governance domain
  Total weight = 100
  Completed tasks weight = 70
  Coverage = 70 / 100 × 100 = 70%
```

### Step 3 — Update `src/data.js`

```js
// Before (Q3 was last quarter, adding Q4):
quarterly: [20, 38, 55, 70],

// After updating Q4:
quarterly: [20, 38, 55, 70],  // Keep historical data
// When moving to next year, rotate: drop Q1, add new Q4
```

### Step 4 — Update `QUARTERS` constant

```js
// src/data.js
export const QUARTERS = ["Q1 2026", "Q2 2026", "Q3 2026", "Q4 2026"];
```

### Step 5 — Deploy / publish

```bash
npm run build
# Deploy /dist folder to your hosting (GitHub Pages, Nginx, etc.)
```

---

## 🛠 Customisation

### Add a new automation domain

```js
// src/data.js — add to AUTOMATION_AREAS array:
{
  id: "etl_orchestration",
  label: "ETL & Orchestration Automation",
  icon: "🔀",
  color: "#6EE7B7",
  description: "Ab Initio pipeline monitoring, APScheduler orchestration, ...",
  tasks: [
    { name: "Ab Initio pipeline health checks", weight: 15 },
    { name: "APScheduler job failure alerting",  weight: 12 },
    // ...add up to 10 tasks, weights should sum to ~100
  ],
  quarterly: [0, 0, 0, 0],  // start at 0, update each quarter
},
```

### Add a new quarter (new year)

1. Update `QUARTERS` to the new 4 quarters.
2. Shift historical data: drop the oldest quarter from each `quarterly` array
   and append the new quarter score.

### Change thresholds

In `App.jsx`, search for the status color logic:
```js
const statusColor = pct >= 70 ? "#34D399" : pct >= 40 ? "#FBBF24" : "#F87171";
```
Adjust the `70` and `40` thresholds to match your maturity targets.

---

## 🧰 Tech Stack

| Layer      | Technology         |
|------------|--------------------|
| Framework  | React 18           |
| Bundler    | Vite 6             |
| Charts     | Vanilla SVG        |
| Fonts      | DM Sans + DM Mono (Google Fonts) |
| Styling    | Plain CSS (no Tailwind dependency) |

No charting library required — all gauges, sparklines, and bars are raw SVG/CSS.

---

## 📋 Embedding in SharePoint / Teams

Build the app and host the `/dist` folder on any static server, then embed via
an iframe in SharePoint or Power BI Embedded:

```html
<iframe
  src="https://your-host/automation-dashboard/"
  width="100%"
  height="900"
  frameborder="0"
/>
```

---

## 📄 License

Internal use — Teradata Data Platform Team.
